-Autor: Pablo de Francisco de la Torre
-Fecha: 20/12/2021
-Titulo: Simulador de hoteles
-Abstract: También hay una clase padre (Ecommerce) y hereda de una hija (Hotel), ambas con sus getters y setters correspondientes. He creado otra clase padre (Worker) y hereda de una hija (Employee), al igual que la anterior, con sus getters y setters correspondientes. Además tiene una clase "BookRoom" y otra "PersonMethods" dónde se hacen las principales funciones. Otras clases que también he utilizado son "Date", "Internacionalizaion", "Read", "Cities". Para que el main quede mejor organizado he creado una clase "Menus" donde albergo todos los menús necesarios.

He añadido un clase interface (IRegister) que sirve para crear un inicio de sesión para el cliente y los trabajadores ahora con genéricos. Y la clase Register donde se verifica que el ID de un usuario ya registrado coincida con la contraseña asignada por el mismo, si es así puedes iniciar sesión como cliente o coomo trabajador.

Además he añadido una clase MathHotel que calcula el dinero total de la app. Y una clase client que guarda el nombre del cliente utilizado para los Threads y los tiempos de compra.

Los hoteles se guardan en un Array en la clase BookRoom y se instancian en el main, así cargándose todos los atributos de los hoteles. Los empleados es similar al anterior salvo por que se guardan en un clase PersonMethods.

También al contar con internacionalización cuenta con la posiblidad de cambiar a otros idiomas (La foto tiene un trozo de cada idioma para visualizar de forma rápida cómo se vería):

Español
Inglés
Alemán
Francés

-Fuentes empleadas:
   https://github.com/mgh99/Practica-Java/tree/main/src
   http://bitsmi.com/2016/06/12/resourcebundle-localizacion-de-recursos/
   https://programacion.net/articulo/internacionalizacion_de_programas_java_140/6
   https://es.stackoverflow.com/questions/209193/encriptaci%C3%B3n-de-datos-en-java-con-javax-crypto
   campus virtual de tecnicas de programación avanzada de este curso y del curso pasado

-Otros:Se que debería optimizar más el simulador pero lo he estado probandolo y no lo he conseguido por eso te lo mando así