package reservahotel;

import java.awt.FlowLayout;
import java.util.*;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import reservahotel.register.personRegister;
import javax.swing.*;

/**
 * 
 * @author Pablo de Francisco de la Torre
 *
 */
public class main {
     
	public static void main(String[] args) throws Exception {
         Menu op= new Menu();
         op.menu();
	}
       
}