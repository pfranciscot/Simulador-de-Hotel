package reservahotel;

import java.util.*;

public class Employee extends worker{
	
	// Atributos
	static ResourceBundle myBundle = ResourceBundle.getBundle("MessagesBundle");
	
	@SuppressWarnings("unused")
	private static List<Employee> employees;
	
	// Contructor por defecto
	public Employee() {
		
	}

	// Contructor con par�metros
	public Employee(String dni, String name, String surname, String nameHotel, String job) {

		super (dni, name, surname, nameHotel, job);

	}

	//M�todos
	
	@Override
	public String toString() {

		return super.toString();
	}



}