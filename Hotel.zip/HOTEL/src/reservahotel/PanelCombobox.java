package reservahotel;

import java.awt.*;
import javax.swing.*;

public class PanelCombobox extends JPanel {
	private JComboBox b1,b2,b3,b4;
	 String[] dia = { "1", "2", "3", "4", "5","6","7","8","9","10", "11", "12","13","14","15","16","17", "18","19","20","21","22","23", "24","25","26","27","28","29","30","31"};
	 String[] mes = { "enero", "febrero", "marzo", "abril", "mayo","junio","julio","agosto","septiembre","octubre", "noviembre", "diciembre"};
	 String[] a�o = { "2021", "2022", "2023", "2024", "2025","2026","2027","2028","2029","2030", "2031", "2032"};
	 String[] ciudad = { "Madrid", "Barcelona", "Valencia", "Sevilla", "Granada","Burgos","C�diz","Almeria","Le�n","Oviedo", "Gij�n", "Ourense", "A Coru�a","Valladolid"," Huelva","Castellon", "Alicante","Zaragoza", "Toledo", "Ciudad Real","Salamanca"};
	
	public PanelCombobox() {
	    	setLayout(new FlowLayout());
	    	
	    	JLabel txt = new JLabel("Seleccione la fecha de su reserva: ");
	    	add(txt);
	    	
	    	b1 = new JComboBox(dia);
	    	b1.setSize(600,600);
	    	add(b1);
	    	
	    	b2 = new JComboBox(mes);
	    	b2.setSize(600,600);
	    	add(b2);
	    	
	    	b3 = new JComboBox(a�o);
	    	b3.setSize(600,600);
	    	add(b3);
	    	
	    	b4 = new JComboBox(ciudad );
	    	b4.setSize(600,600);
	    	add(b4);
	    }
	
}
