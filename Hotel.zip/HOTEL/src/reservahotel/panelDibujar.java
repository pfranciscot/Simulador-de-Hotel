package reservahotel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.*;
import javax.imageio.*;

public class panelDibujar extends JPanel{
	
	private BufferedImage image,image2,image3,image4,image5 = null; 
	
	public panelDibujar() {
		try {
			image =ImageIO.read(getClass().getResource("/hotel.jfif"));
			image2 = ImageIO.read( getClass().getResource("/hotel2.jpg"));
			image3= ImageIO.read(getClass().getResource("/hotel3.jfif"));
			image4= ImageIO.read(getClass().getResource("/hotel4.jfif"));
			image5= ImageIO.read(getClass().getResource("/hotel5.jfif"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	    
		JLabel picLabel= new JLabel(new ImageIcon(image));
		JLabel picLabel2= new JLabel(new ImageIcon(image2));
		JLabel picLabel3= new JLabel(new ImageIcon(image3));
		JLabel picLabel4= new JLabel(new ImageIcon(image4));
		JLabel picLabel5= new JLabel(new ImageIcon(image5));
        picLabel.setSize(500,500);
        picLabel2.setSize(500,500);
        picLabel3.setSize(500,500); 
        picLabel4.setSize(500,500);
        picLabel5.setSize(500,500);
		add(picLabel);
		add(picLabel2);
		add(picLabel3);
		add(picLabel4);
		add(picLabel5);
	}
    
}
