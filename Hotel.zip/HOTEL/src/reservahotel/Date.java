package reservahotel;

import java.time.LocalDate;

public class Date {
	public void dateNow() {

		LocalDate today = LocalDate.now();
		System.out.println("\t******************\n" +"\t**  " + today + "  **\n" +"\t******************");

	}
}
